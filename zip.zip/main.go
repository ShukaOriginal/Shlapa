package main

import (
	"fmt"
	"golang.org/x/sys/windows"
	"syscall"
	"unsafe"
)

type Map struct {
	id        int32
	cells     [][]cell
	lifecells [][]lifecell
}

type cell struct {
	organic   int32
	energy    int32
	iluminate int32
}

type lifecell struct {
	celltype int32
	helth    int32
	genom    [][]int32
}

// public static int[][] Initgenom(width int64,height int64,maxnum int64)

func main() {
	dll, err := windows.LoadLibrary("GenomeOperation.dll")
	if err != nil {
		fmt.Println("Ошибка загрузки DLL:", err)
		return
	}
	defer windows.FreeLibrary(dll)

	proc, err := windows.GetProcAddress(dll, "GenomeOperation.Create.CreateNewGenome")
	if err != nil {
		fmt.Println("Ошибка получения адреса функции:", err)
		return
	}

	var x int = 10
	var y int = 10
	var z int = 50
	var result [10][10]int

	p := uintptr(unsafe.Pointer(&result))
	//uintptr(unsafe.Pointer(&result))

	p, _, _ = syscall.Syscall(proc, 3, uintptr(unsafe.Pointer(&x)), uintptr(unsafe.Pointer(&y)), uintptr(unsafe.Pointer(&z)))
	fmt.Println("Результат функции из DLL:", p)
}
